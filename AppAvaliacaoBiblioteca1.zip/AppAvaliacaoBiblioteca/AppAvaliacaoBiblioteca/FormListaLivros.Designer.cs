﻿namespace AppAvaliacaoBiblioteca
{
    partial class FormListaLivros
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblTituloTela = new Label();
            grpFiltros = new GroupBox();
            txtGenero = new TextBox();
            lblGenero = new Label();
            txtTitulo = new TextBox();
            lblTitulo = new Label();
            btnFiltrar = new Button();
            dgvLivros = new DataGridView();
            grpFiltros.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvLivros).BeginInit();
            SuspendLayout();
            // 
            // lblTituloTela
            // 
            lblTituloTela.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblTituloTela.Location = new Point(8, 20);
            lblTituloTela.Name = "lblTituloTela";
            lblTituloTela.Size = new Size(780, 23);
            lblTituloTela.TabIndex = 0;
            lblTituloTela.Text = "Listar Livros";
            lblTituloTela.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // grpFiltros
            // 
            grpFiltros.Controls.Add(txtGenero);
            grpFiltros.Controls.Add(lblGenero);
            grpFiltros.Controls.Add(txtTitulo);
            grpFiltros.Controls.Add(lblTitulo);
            grpFiltros.Location = new Point(12, 55);
            grpFiltros.Name = "grpFiltros";
            grpFiltros.Size = new Size(776, 90);
            grpFiltros.TabIndex = 1;
            grpFiltros.TabStop = false;
            grpFiltros.Text = "FILTROS";
            // 
            // txtGenero
            // 
            txtGenero.Location = new Point(395, 48);
            txtGenero.Name = "txtGenero";
            txtGenero.Size = new Size(350, 23);
            txtGenero.TabIndex = 3;
            // 
            // lblGenero
            // 
            lblGenero.AutoSize = true;
            lblGenero.Location = new Point(395, 28);
            lblGenero.Name = "lblGenero";
            lblGenero.Size = new Size(48, 15);
            lblGenero.TabIndex = 2;
            lblGenero.Text = "Gênero:";
            // 
            // txtTitulo
            // 
            txtTitulo.Location = new Point(15, 48);
            txtTitulo.Name = "txtTitulo";
            txtTitulo.Size = new Size(350, 23);
            txtTitulo.TabIndex = 1;
            // 
            // lblTitulo
            // 
            lblTitulo.AutoSize = true;
            lblTitulo.Location = new Point(15, 28);
            lblTitulo.Name = "lblTitulo";
            lblTitulo.Size = new Size(41, 15);
            lblTitulo.TabIndex = 0;
            lblTitulo.Text = "Título:";
            // 
            // btnFiltrar
            // 
            btnFiltrar.Font = new Font("Arial", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnFiltrar.Location = new Point(330, 155);
            btnFiltrar.Name = "btnFiltrar";
            btnFiltrar.Size = new Size(140, 30);
            btnFiltrar.TabIndex = 2;
            btnFiltrar.Text = "FILTRAR";
            btnFiltrar.UseVisualStyleBackColor = true;
            btnFiltrar.Click += btnFiltrar_Click;
            // 
            // dgvLivros
            // 
            dgvLivros.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvLivros.Location = new Point(12, 200);
            dgvLivros.Name = "dgvLivros";
            dgvLivros.Size = new Size(776, 230);
            dgvLivros.TabIndex = 3;
            dgvLivros.CellContentClick += dgvLivros_CellContentClick;
            // 
            // FormListaLivros
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(dgvLivros);
            Controls.Add(btnFiltrar);
            Controls.Add(grpFiltros);
            Controls.Add(lblTituloTela);
            Name = "FormListaLivros";
            Text = "Listar Livros";
            Load += FormListaLivros_Load;
            grpFiltros.ResumeLayout(false);
            grpFiltros.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgvLivros).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Label lblTituloTela;
        private GroupBox grpFiltros;
        private Label lblTitulo;
        private TextBox txtTitulo;
        private Label lblGenero;
        private TextBox txtGenero;
        private Button btnFiltrar;
        private DataGridView dgvLivros;
    }
}