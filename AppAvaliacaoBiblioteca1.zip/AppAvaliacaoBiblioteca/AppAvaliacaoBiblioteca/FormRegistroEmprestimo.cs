﻿using AppAvaliacaoBiblioteca.Contexto;

namespace AppAvaliacaoBiblioteca
{
    public partial class FormRegistroEmprestimo : Form
    {

        List<int> livrosEscolhidos = new List<int>();

        DateTime dataEmprestimo = DateTime.Today;
        DateTime dataDevolucao = DateTime.Today.AddDays(7);

        public FormRegistroEmprestimo()
        {
            InitializeComponent();
        }

        private void FormRegistroEmprestimo_Load(object sender, EventArgs e)
        {

            txtTitulo.ReadOnly = true;
            txtAutor.ReadOnly = true;
            txtGenero.ReadOnly = true;
            txtExemplares.ReadOnly = true;
            txtMatricula.ReadOnly = true;
            txtDataEmprestimo.ReadOnly = true;
            txtDevolucao.ReadOnly = true;


            txtDataEmprestimo.Text = dataEmprestimo.ToString("dd/MM/yyyy");
            txtDevolucao.Text = dataDevolucao.ToString("dd/MM/yyyy");


            foreach (Leitor l in BancoDados.Leitores)
            {
                cmbLeitor.Items.Add(l.Nome);
            }
            foreach (var livro in BancoDados.Livros)
            {
                cmbLivro.Items.Add(livro.Titulo);
            }



            dgvEmprestimo.Columns.Add("colCodigo", "Código");
            dgvEmprestimo.Columns.Add("colMatricula", "Matrícula");
            dgvEmprestimo.Columns.Add("colTitulo", "Título");
            dgvEmprestimo.Columns.Add("colAutor", "Autor");
            dgvEmprestimo.Columns.Add("colEmprestimo", "Empréstimo");
            dgvEmprestimo.Columns.Add("colDevolucao", "Devolução");
            dgvEmprestimo.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvEmprestimo.AllowUserToAddRows = false;
            dgvEmprestimo.ReadOnly = true;
        }

        private void cmbLeitor_SelectedIndexChanged(object sender, EventArgs e)
        {

            if (cmbLeitor.SelectedIndex == -1)
            {
                return;
            }


            Leitor leitor = BancoDados.Leitores[cmbLeitor.SelectedIndex];
            txtMatricula.Text = leitor.Matricula;
        }

        private void cmbLivro_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbLivro.SelectedIndex == -1)
            {
                return;
            }

            var livro = BancoDados.Livros[cmbLivro.SelectedIndex];
            txtTitulo.Text = livro.Titulo;
            txtAutor.Text = livro.Autor;
            txtGenero.Text = livro.Genero;
            txtExemplares.Text = livro.Exemplares.ToString();
        }

        private void btnAdicionar_Click(object sender, EventArgs e)
        {
            if (cmbLeitor.SelectedIndex == -1)
            {
                MessageBox.Show("Selecione um leitor!", "ADS/JIPA", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (cmbLivro.SelectedIndex == -1)
            {
                MessageBox.Show("Selecione um livro!", "ADS/JIPA", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int posicao = cmbLivro.SelectedIndex;
            var livro = BancoDados.Livros[posicao];

            if (livrosEscolhidos.Count == 3)
            {
                MessageBox.Show("Cada empréstimo pode ter no máximo 3 livros!", "ADS/JIPA", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (livro.Exemplares == 0)
            {
                MessageBox.Show("Este livro não tem exemplares disponíveis!", "ADS/JIPA", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (livrosEscolhidos.Contains(posicao))
            {
                MessageBox.Show("Este livro já foi adicionado ao empréstimo!", "ADS/JIPA", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            livrosEscolhidos.Add(posicao);

            dgvEmprestimo.Rows.Add(BancoDados.ProximoCodigoEmprestimo, txtMatricula.Text,
                                   livro.Titulo, livro.Autor,
                                   txtDataEmprestimo.Text, txtDevolucao.Text);


            cmbLeitor.Enabled = false;
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            if (livrosEscolhidos.Count == 0)
            {
                MessageBox.Show("Adicione pelo menos um livro ao empréstimo!", "ADS/JIPA", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int codigo = BancoDados.ProximoCodigoEmprestimo;
            Leitor leitor = BancoDados.Leitores[cmbLeitor.SelectedIndex];

            foreach (int posicao in livrosEscolhidos)
            {
                var livro = BancoDados.Livros[posicao];

                BancoDados.Emprestimos.Add((codigo, leitor.Matricula, leitor.Nome,
                                            livro.Titulo, livro.Autor,
                                            dataEmprestimo, dataDevolucao));

                livro.Exemplares--;
                BancoDados.Livros[posicao] = livro;
            }

            BancoDados.ProximoCodigoEmprestimo++;

            MessageBox.Show("Empréstimo " + codigo + " salvo com sucesso!", "ADS/JIPA", MessageBoxButtons.OK, MessageBoxIcon.Information);

            LimparTela();
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            LimparTela();
        }

        private void LimparTela()
        {
            livrosEscolhidos.Clear();
            dgvEmprestimo.Rows.Clear();

            cmbLeitor.Enabled = true;
            cmbLeitor.SelectedIndex = -1;
            cmbLivro.SelectedIndex = -1;

            txtMatricula.Clear();
            txtTitulo.Clear();
            txtAutor.Clear();
            txtGenero.Clear();
            txtExemplares.Clear();
        }

        private void dgvEmprestimo_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }


}

