﻿using AppAvaliacaoBiblioteca.Contexto;

namespace AppAvaliacaoBiblioteca
{
    public partial class FormListaLivros : Form
    {
        public FormListaLivros()
        {
            InitializeComponent();
        }

        private void FormListaLivros_Load(object sender, EventArgs e)
        {

            dgvLivros.Columns.Add("colId", "Id");
            dgvLivros.Columns.Add("colTitulo", "Título");
            dgvLivros.Columns.Add("colAutor", "Autor");
            dgvLivros.Columns.Add("colGenero", "Gênero");
            dgvLivros.Columns.Add("colExemplares", "Exemplares");
            dgvLivros.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvLivros.AllowUserToAddRows = false;
            dgvLivros.ReadOnly = true;

            Filtrar();
        }

        private void btnFiltrar_Click(object sender, EventArgs e)
        {
            Filtrar();
        }

        private void Filtrar()
        {
            string filtroTitulo = txtTitulo.Text.Trim().ToLower();
            string filtroGenero = txtGenero.Text.Trim().ToLower();

            dgvLivros.Rows.Clear();

            foreach (var livro in BancoDados.Livros)
            {

                if (livro.Titulo.ToLower().Contains(filtroTitulo) &&
                    livro.Genero.ToLower().Contains(filtroGenero))
                {
                    dgvLivros.Rows.Add(livro.Id, livro.Titulo, livro.Autor,
                                       livro.Genero, livro.Exemplares);
                }
            }
        }

        private void dgvLivros_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}