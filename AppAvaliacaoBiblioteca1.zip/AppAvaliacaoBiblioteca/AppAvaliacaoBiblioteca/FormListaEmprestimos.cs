﻿using AppAvaliacaoBiblioteca.Contexto;

namespace AppAvaliacaoBiblioteca
{
    public partial class FormListaEmprestimos : Form
    {
        public FormListaEmprestimos()
        {
            InitializeComponent();
        }

        private void FormListaEmprestimos_Load(object sender, EventArgs e)
        {

            dgvEmprestimos.Columns.Add("colCodigo", "Código");
            dgvEmprestimos.Columns.Add("colMatricula", "Matrícula");
            dgvEmprestimos.Columns.Add("colLeitor", "Leitor");
            dgvEmprestimos.Columns.Add("colTitulo", "Título");
            dgvEmprestimos.Columns.Add("colEmprestimo", "Empréstimo");
            dgvEmprestimos.Columns.Add("colDevolucao", "Devolução");
            dgvEmprestimos.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvEmprestimos.AllowUserToAddRows = false;
            dgvEmprestimos.ReadOnly = true;


            Filtrar();
        }

        private void btnFiltrar_Click(object sender, EventArgs e)
        {
            Filtrar();
        }

        private void Filtrar()
        {
            string filtroMatricula = txtMatricula.Text.Trim();
            string filtroCodigo = txtCodigo.Text.Trim();

            dgvEmprestimos.Rows.Clear();

            foreach (var emprestimo in BancoDados.Emprestimos)
            {

                bool matriculaOk = emprestimo.Matricula.Contains(filtroMatricula);


                bool codigoOk = filtroCodigo == "" || emprestimo.Codigo.ToString() == filtroCodigo;

                if (matriculaOk && codigoOk)
                {
                    dgvEmprestimos.Rows.Add(emprestimo.Codigo, emprestimo.Matricula,
                                            emprestimo.Leitor, emprestimo.Titulo,
                                            emprestimo.DataEmprestimo.ToString("dd/MM/yyyy"),
                                            emprestimo.DataDevolucao.ToString("dd/MM/yyyy"));
                }
            }
        }
    }
}