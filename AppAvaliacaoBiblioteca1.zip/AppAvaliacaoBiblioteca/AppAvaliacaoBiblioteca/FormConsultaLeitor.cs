﻿using AppAvaliacaoBiblioteca.Contexto;

namespace AppAvaliacaoBiblioteca
{
    public partial class FormConsultaLeitor : Form
    {
        public FormConsultaLeitor()
        {
            InitializeComponent();
        }

        private void FormConsultaLeitor_Load(object sender, EventArgs e)
        {
            txtNome.ReadOnly = true;
            txtMatricula.ReadOnly = true;
            txtCurso.ReadOnly = true;
            txtTelefone.ReadOnly = true;
            txtTotal.ReadOnly = true;

            foreach (Leitor l in BancoDados.Leitores)
            {
                cmbLeitor.Items.Add(l.Nome);
            }
        }

        private void cmbLeitor_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbLeitor.SelectedIndex == -1)
            {
                return;
            }

            Leitor leitor = BancoDados.Leitores[cmbLeitor.SelectedIndex];

            txtNome.Text = leitor.Nome;
            txtMatricula.Text = leitor.Matricula;
            txtCurso.Text = leitor.Curso;
            txtTelefone.Text = leitor.Telefone;

            int total = 0;
            foreach (var emprestimo in BancoDados.Emprestimos)
            {
                if (emprestimo.Matricula == leitor.Matricula)
                {
                    total++;
                }
            }

            txtTotal.Text = total.ToString();
        }
    }
}