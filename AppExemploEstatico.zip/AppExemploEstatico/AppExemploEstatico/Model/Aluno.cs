﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppExemploEstatico.Model
{
    public class Aluno
    {
        public int Id { get; set; } // id do aluno
        public string Nome { get; set; } // o nome do aluno
        public double Nota1 { get; set; } // primeira nota
        public double Nota2 { get; set; } // segunda nota
        public double Media {  get; set; } // resultado da media das duas notas
        public string Situacao { get; set; } // verifica se esta aprovado ou reprovado

    }
}
