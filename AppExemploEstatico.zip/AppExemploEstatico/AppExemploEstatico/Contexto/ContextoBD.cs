﻿using AppExemploEstatico.Formularios;
using AppExemploEstatico.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AppExemploEstatico.Model;


namespace AppExemploEstatico.Contexto
{
   public class ContextoBD
   {
        //Repositorio
        public static List<Aluno> salaDeAula = new List<Aluno>();

   }
}
