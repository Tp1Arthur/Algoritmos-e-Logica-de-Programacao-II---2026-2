﻿namespace AppExemploEstatico.Formularios
{
    partial class FormListar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.dgvTabela = new System.Windows.Forms.DataGridView();
            this.btRemoverFiltro = new System.Windows.Forms.Button();
            this.btFiltro = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTabela)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, -1);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(776, 54);
            this.label1.TabIndex = 0;
            this.label1.Text = "LISTAR ALUNOS (ordem numérica)";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // dgvTabela
            // 
            this.dgvTabela.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTabela.Location = new System.Drawing.Point(26, 56);
            this.dgvTabela.Name = "dgvTabela";
            this.dgvTabela.Size = new System.Drawing.Size(739, 161);
            this.dgvTabela.TabIndex = 1;
            // 
            // btRemoverFiltro
            // 
            this.btRemoverFiltro.Image = global::AppExemploEstatico.Properties.Resources.filter_remove_outline_icon_139564;
            this.btRemoverFiltro.Location = new System.Drawing.Point(667, 12);
            this.btRemoverFiltro.Name = "btRemoverFiltro";
            this.btRemoverFiltro.Size = new System.Drawing.Size(75, 38);
            this.btRemoverFiltro.TabIndex = 5;
            this.btRemoverFiltro.UseVisualStyleBackColor = true;
            this.btRemoverFiltro.Click += new System.EventHandler(this.btRemoverFiltro_Click);
            // 
            // btFiltro
            // 
            this.btFiltro.Image = global::AppExemploEstatico.Properties.Resources.filter_icon_136624;
            this.btFiltro.Location = new System.Drawing.Point(586, 12);
            this.btFiltro.Name = "btFiltro";
            this.btFiltro.Size = new System.Drawing.Size(75, 38);
            this.btFiltro.TabIndex = 4;
            this.btFiltro.UseVisualStyleBackColor = true;
            this.btFiltro.Click += new System.EventHandler(this.btFiltro_Click);
            // 
            // FormListar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btRemoverFiltro);
            this.Controls.Add(this.btFiltro);
            this.Controls.Add(this.dgvTabela);
            this.Controls.Add(this.label1);
            this.Name = "FormListar";
            this.Text = "FormListar";
            ((System.ComponentModel.ISupportInitialize)(this.dgvTabela)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dgvTabela;
        private System.Windows.Forms.Button btFiltro;
        private System.Windows.Forms.Button btRemoverFiltro;
    }
}