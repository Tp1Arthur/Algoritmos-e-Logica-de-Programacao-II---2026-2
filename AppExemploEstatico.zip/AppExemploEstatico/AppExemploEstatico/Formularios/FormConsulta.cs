﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AppExemploEstatico.Model;
using AppExemploEstatico.Contexto;

namespace AppExemploEstatico.Formularios
{
    public partial class FormConsulta : Form
    {
        int contExec = 0;
        public FormConsulta()
        {
            InitializeComponent();
            cbSelecionar.DataSource = ContextoBD.salaDeAula.ToList();
            cbSelecionar.DisplayMember = "Nome";
            cbSelecionar.SelectedIndex = -1;
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            contExec++;
            int linhaSelecionada = cbSelecionar.SelectedIndex;
            if(linhaSelecionada >-1 && contExec > 1)
            {
                var aluno = ContextoBD.salaDeAula[linhaSelecionada];
                txtId.Text = aluno.Id.ToString();
                txtNome.Text = aluno.Nome;
                txtNota1.Text = aluno.Nota1.ToString();
                txtNota2.Text = aluno.Nota2.ToString();
                txtMedia.Text = aluno.Media.ToString();
                txtSituacao.Text = aluno.Situacao;
            }
        }

        private void txtNota2_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtNota1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
