﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AppExemploEstatico.Contexto;
using AppExemploEstatico;
using AppExemploEstatico.Model;

namespace AppExemploEstatico.Formularios
{
    public partial class FormListar : Form
    {
        List<Aluno> alunos = new List<Aluno>();

        public FormListar()
        {
            InitializeComponent();
            btRemoverFiltro.Enabled = false;
            alunos = ContextoBD.salaDeAula.ToList();
            dgvTabela.DataSource = ContextoBD.salaDeAula.ToList();
            
            
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void btFiltro_Click(object sender, EventArgs e)
        {

        }

        private void btRemoverFiltro_Click(object sender, EventArgs e)
        {
            btFiltro.Enabled = true;
            btRemoverFiltro.Enabled = false;
            dgvTabela.DataSource = alunos.ToList(); //lista sem filtros
        }
    }
}
