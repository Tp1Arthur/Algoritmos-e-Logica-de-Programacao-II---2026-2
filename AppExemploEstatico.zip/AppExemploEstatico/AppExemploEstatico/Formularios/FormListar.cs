﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AppExemploEstatico.Contexto;

namespace AppExemploEstatico.Formularios
{
    public partial class FormListar : Form
    {
        public FormListar()
        {
            InitializeComponent();
            dgvTabela.DataSource = ContextoBD.salaDeAula.ToList();
            TabelaOA.DataSource = ContextoBD.salaDeAula.OrderBy(aluno => aluno.Nome).ToList();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
