﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AppExemploEstatico.Model;
using AppExemploEstatico.Contexto;


namespace AppExemploEstatico.Formularios
{
    public partial class FormCadastro : Form
    {
        //int idAluno = 1; //Não é estatica
        static int idAluno = 1;


        public FormCadastro()
        {
            InitializeComponent();
            txtId.Text = idAluno.ToString();
        }

        private void FormCadastro_Load(object sender, EventArgs e)
        {

        }

        private void btSalvar_Click(object sender, EventArgs e)
        {
            Aluno aluno = new Aluno();
            aluno.Id = idAluno;
            aluno.Nome = txtNome.Text;
            aluno.Nota1 = Convert.ToDouble(txtNota1.Text);
            aluno.Nota2 = Convert.ToDouble(txtNota2.Text);
            aluno.Media = (aluno.Nota1 + aluno.Nota2) / 2;

            if (aluno.Media >= 60)
            {
                aluno.Situacao = "APROVADO(A)";
            }
            else
            {
                aluno.Situacao = "REPROVADO(A)";
            }
            ContextoBD.salaDeAula.Add(aluno);
            MessageBox.Show("ALUNO(A) SALVO(A) COM SUCESSO!", "ADS/JIPA", MessageBoxButtons.OK, MessageBoxIcon.Information);
            idAluno++;
            txtId.Text = idAluno.ToString();
            txtNome.Clear(); txtNota1.Clear(); txtNota2.Clear(); txtNome.Select();
        }

        private void btCancelar_Click(object sender, EventArgs e)
        {
            txtNome.Clear(); txtNota1.Clear(); txtNota2.Clear(); txtNome.Select();
        }
    }
}
