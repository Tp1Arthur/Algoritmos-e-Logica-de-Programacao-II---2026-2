﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AppExemploEstatico.Contexto;
using AppExemploEstatico.Model; //acessar o repositório

namespace AppExemploEstatico.Formularios
{
    public partial class FormListar : Form
    {
        List<Aluno> alunos = new List<Aluno>();
        public FormListar()
        {
            InitializeComponent();
            dgvTabela.DataSource = ContextoBD.salaDeAula.ToList();
            alunos = ContextoBD.salaDeAula.ToList();
            btRemoverFiltro.Enabled = false;
        }

        private void btFiltro_Click(object sender, EventArgs e)
        {
            btFiltro.Enabled = false; 
            btRemoverFiltro.Enabled = true;
            var listaFiltro = alunos.Where(a => a.Nome.Contains(txtNome.Text)).ToList();
            dgvTabela.DataSource = listaFiltro.ToList(); //dados filtrados
        }

        private void btRemoverFiltro_Click(object sender, EventArgs e)
        {
            btFiltro.Enabled = true;
            btRemoverFiltro.Enabled = false;
            dgvTabela.DataSource = alunos.ToList(); //lista sem filtros
            txtNome.Clear();
            txtNome.Select(); 
        }
    }
}
