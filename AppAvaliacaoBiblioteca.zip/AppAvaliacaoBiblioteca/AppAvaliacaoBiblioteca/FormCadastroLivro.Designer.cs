﻿namespace AppAvaliacaoBiblioteca
{
    partial class FormCadastroLivro
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            txtTitulo = new TextBox();
            Titulo = new Label();
            label2 = new Label();
            txtAutor = new TextBox();
            label3 = new Label();
            txtGenero = new TextBox();
            label4 = new Label();
            txtExemplares = new TextBox();
            btnCadastrar = new Button();
            btnCancelar = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.Font = new Font("Arial", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(12, 9);
            label1.Name = "label1";
            label1.Size = new Size(776, 45);
            label1.TabIndex = 0;
            label1.Text = "Cadastrar Livros";
            label1.TextAlign = ContentAlignment.MiddleCenter;
            label1.Click += label1_Click;
            // 
            // txtTitulo
            // 
            txtTitulo.BackColor = Color.FromArgb(224, 224, 224);
            txtTitulo.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtTitulo.Location = new Point(12, 81);
            txtTitulo.Name = "txtTitulo";
            txtTitulo.Size = new Size(776, 29);
            txtTitulo.TabIndex = 1;
            txtTitulo.TextChanged += txtTitulo_TextChanged;
            // 
            // Titulo
            // 
            Titulo.AutoSize = true;
            Titulo.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Titulo.Location = new Point(12, 59);
            Titulo.Name = "Titulo";
            Titulo.Size = new Size(58, 19);
            Titulo.TabIndex = 2;
            Titulo.Text = "Titulo:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(12, 129);
            label2.Name = "label2";
            label2.Size = new Size(57, 19);
            label2.TabIndex = 4;
            label2.Text = "Autor:";
            // 
            // txtAutor
            // 
            txtAutor.BackColor = Color.FromArgb(224, 224, 224);
            txtAutor.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtAutor.Location = new Point(12, 151);
            txtAutor.Name = "txtAutor";
            txtAutor.Size = new Size(776, 29);
            txtAutor.TabIndex = 3;
            txtAutor.TextChanged += txtAutor_TextChanged;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(12, 207);
            label3.Name = "label3";
            label3.Size = new Size(71, 19);
            label3.TabIndex = 6;
            label3.Text = "Gênero:";
            // 
            // txtGenero
            // 
            txtGenero.BackColor = Color.FromArgb(224, 224, 224);
            txtGenero.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtGenero.Location = new Point(12, 229);
            txtGenero.Name = "txtGenero";
            txtGenero.Size = new Size(776, 29);
            txtGenero.TabIndex = 5;
            txtGenero.TextChanged += txtGenero_TextChanged;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.Location = new Point(12, 285);
            label4.Name = "label4";
            label4.Size = new Size(218, 19);
            label4.TabIndex = 8;
            label4.Text = "Quantidade de exemplares:";
            // 
            // txtExemplares
            // 
            txtExemplares.BackColor = Color.FromArgb(224, 224, 224);
            txtExemplares.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtExemplares.Location = new Point(12, 307);
            txtExemplares.Name = "txtExemplares";
            txtExemplares.Size = new Size(776, 29);
            txtExemplares.TabIndex = 7;
            txtExemplares.TextChanged += txtExemplares_TextChanged;
            // 
            // btnCadastrar
            // 
            btnCadastrar.BackColor = Color.SeaGreen;
            btnCadastrar.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnCadastrar.ForeColor = Color.White;
            btnCadastrar.Location = new Point(233, 384);
            btnCadastrar.Name = "btnCadastrar";
            btnCadastrar.Size = new Size(138, 35);
            btnCadastrar.TabIndex = 9;
            btnCadastrar.Text = "Cadastrar";
            btnCadastrar.UseVisualStyleBackColor = false;
            btnCadastrar.Click += btnCadastrar_Click;
            // 
            // btnCancelar
            // 
            btnCancelar.BackColor = Color.SeaGreen;
            btnCancelar.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnCancelar.ForeColor = Color.White;
            btnCancelar.Location = new Point(419, 384);
            btnCancelar.Name = "btnCancelar";
            btnCancelar.Size = new Size(138, 35);
            btnCancelar.TabIndex = 10;
            btnCancelar.Text = "Cancelar";
            btnCancelar.UseVisualStyleBackColor = false;
            btnCancelar.Click += btnCancelar_Click;
            // 
            // FormCadastroLivro
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(800, 450);
            Controls.Add(btnCancelar);
            Controls.Add(btnCadastrar);
            Controls.Add(label4);
            Controls.Add(txtExemplares);
            Controls.Add(label3);
            Controls.Add(txtGenero);
            Controls.Add(label2);
            Controls.Add(txtAutor);
            Controls.Add(Titulo);
            Controls.Add(txtTitulo);
            Controls.Add(label1);
            Name = "FormCadastroLivro";
            Text = "FormCadastroLivro";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox txtTitulo;
        private Label Titulo;
        private Label label2;
        private TextBox txtAutor;
        private Label label3;
        private TextBox txtGenero;
        private Label label4;
        private TextBox txtExemplares;
        private Button btnCadastrar;
        private Button btnCancelar;
    }
}