﻿using System;
using System.Collections.Generic;
using System.Numerics;
using System.Text;

namespace AppAvaliacaoBiblioteca.Contexto
{
    public static class BancoDados
    {
        public static List<Leitor> Leitores = new List<Leitor>();

        public static List<(int Id, string Titulo, string Autor, string Genero, int Exemplares)> Livros
            = new List<(int, string, string, string, int)>();

        public static List<(int Codigo, string Matricula, string Leitor, string Titulo, string Autor, DateTime DataEmprestimo, DateTime DataDevolucao)> Emprestimos = new List<(int, string, string, string, string, DateTime, DateTime)>();

        public static int ProximoIdLivro = 1;
        public static int ProximoCodigoEmprestimo = 1;
    }
}
