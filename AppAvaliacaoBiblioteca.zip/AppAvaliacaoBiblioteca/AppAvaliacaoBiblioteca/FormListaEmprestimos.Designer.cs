﻿namespace AppAvaliacaoBiblioteca
{
    partial class FormListaEmprestimos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblTituloTela = new Label();
            grpFiltros = new GroupBox();
            lblMatricula = new Label();
            txtMatricula = new TextBox();
            lblCodigo = new Label();
            txtCodigo = new TextBox();
            btnFiltrar = new Button();
            dgvEmprestimos = new DataGridView();
            grpFiltros.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvEmprestimos).BeginInit();
            SuspendLayout();
            // 
            // lblTituloTela
            // 
            lblTituloTela.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblTituloTela.Location = new Point(8, 20);
            lblTituloTela.Name = "lblTituloTela";
            lblTituloTela.Size = new Size(780, 23);
            lblTituloTela.TabIndex = 0;
            lblTituloTela.Text = "Listar Empréstimos";
            lblTituloTela.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // grpFiltros
            // 
            grpFiltros.Controls.Add(txtCodigo);
            grpFiltros.Controls.Add(lblCodigo);
            grpFiltros.Controls.Add(txtMatricula);
            grpFiltros.Controls.Add(lblMatricula);
            grpFiltros.Location = new Point(12, 55);
            grpFiltros.Name = "grpFiltros";
            grpFiltros.Size = new Size(776, 90);
            grpFiltros.TabIndex = 1;
            grpFiltros.TabStop = false;
            grpFiltros.Text = "FILTROS";
            // 
            // lblMatricula
            // 
            lblMatricula.AutoSize = true;
            lblMatricula.Location = new Point(15, 28);
            lblMatricula.Name = "lblMatricula";
            lblMatricula.Size = new Size(101, 15);
            lblMatricula.TabIndex = 0;
            lblMatricula.Text = "Matrícula do Leitor:";
            // 
            // txtMatricula
            // 
            txtMatricula.Location = new Point(15, 48);
            txtMatricula.Name = "txtMatricula";
            txtMatricula.Size = new Size(350, 23);
            txtMatricula.TabIndex = 1;
            // 
            // lblCodigo
            // 
            lblCodigo.AutoSize = true;
            lblCodigo.Location = new Point(395, 28);
            lblCodigo.Name = "lblCodigo";
            lblCodigo.Size = new Size(112, 15);
            lblCodigo.TabIndex = 2;
            lblCodigo.Text = "Código do Empréstimo:";
            // 
            // txtCodigo
            // 
            txtCodigo.Location = new Point(395, 48);
            txtCodigo.Name = "txtCodigo";
            txtCodigo.Size = new Size(350, 23);
            txtCodigo.TabIndex = 3;
            // 
            // btnFiltrar
            // 
            btnFiltrar.Font = new Font("Arial", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnFiltrar.Location = new Point(330, 155);
            btnFiltrar.Name = "btnFiltrar";
            btnFiltrar.Size = new Size(140, 30);
            btnFiltrar.TabIndex = 2;
            btnFiltrar.Text = "FILTRAR";
            btnFiltrar.UseVisualStyleBackColor = true;
            btnFiltrar.Click += btnFiltrar_Click;
            // 
            // dgvEmprestimos
            // 
            dgvEmprestimos.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvEmprestimos.Location = new Point(12, 200);
            dgvEmprestimos.Name = "dgvEmprestimos";
            dgvEmprestimos.Size = new Size(776, 230);
            dgvEmprestimos.TabIndex = 3;
            // 
            // FormListaEmprestimos
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(dgvEmprestimos);
            Controls.Add(btnFiltrar);
            Controls.Add(grpFiltros);
            Controls.Add(lblTituloTela);
            Name = "FormListaEmprestimos";
            Text = "Listar Empréstimos";
            Load += FormListaEmprestimos_Load;
            grpFiltros.ResumeLayout(false);
            grpFiltros.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgvEmprestimos).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Label lblTituloTela;
        private GroupBox grpFiltros;
        private Label lblMatricula;
        private TextBox txtMatricula;
        private Label lblCodigo;
        private TextBox txtCodigo;
        private Button btnFiltrar;
        private DataGridView dgvEmprestimos;
    }
}