﻿using AppAvaliacaoBiblioteca.Contexto;

namespace AppAvaliacaoBiblioteca
{
    public partial class FormRegistroEmprestimo : Form
    {

        List<(int Posicao, string Titulo, string Autor)> carrinho = new List<(int, string, string)>();

        DateTime dataEmprestimo = DateTime.Today;
        DateTime dataDevolucao = DateTime.Today.AddDays(7);

        public FormRegistroEmprestimo()
        {
            InitializeComponent();
        }

        private void FormRegistroEmprestimo_Load(object sender, EventArgs e)
        {
            txtTitulo.ReadOnly = true;
            txtAutor.ReadOnly = true;
            txtGenero.ReadOnly = true;
            txtExemplares.ReadOnly = true;
            txtMatricula.ReadOnly = true;
            txtDataEmprestimo.ReadOnly = true;
            txtDevolucao.ReadOnly = true;

            txtDataEmprestimo.Text = dataEmprestimo.ToString("dd/MM/yyyy");
            txtDevolucao.Text = dataDevolucao.ToString("dd/MM/yyyy");


            cmbLeitor.DataSource = BancoDados.Leitores.ToList();
            cmbLeitor.DisplayMember = "Nome";
            cmbLivro.DataSource = BancoDados.Livros.Select(x => x.Titulo).ToList();

            dgvEmprestimo.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;


            LimparTela();
        }

        private void cmbLeitor_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbLeitor.SelectedIndex == -1)
            {
                return;
            }

            Leitor leitor = BancoDados.Leitores[cmbLeitor.SelectedIndex];
            txtMatricula.Text = leitor.Matricula;
        }

        private void cmbLivro_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbLivro.SelectedIndex == -1)
            {
                return;
            }

            var livro = BancoDados.Livros[cmbLivro.SelectedIndex];
            txtTitulo.Text = livro.Titulo;
            txtAutor.Text = livro.Autor;
            txtGenero.Text = livro.Genero;
            txtExemplares.Text = livro.Exemplares.ToString();
        }

        private void btnAdicionar_Click(object sender, EventArgs e)
        {
            if (cmbLeitor.SelectedIndex == -1)
            {
                MessageBox.Show("Selecione um leitor!", "ADS/JIPA", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (cmbLivro.SelectedIndex == -1)
            {
                MessageBox.Show("Selecione um livro!", "ADS/JIPA", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int posicao = cmbLivro.SelectedIndex;
            var livro = BancoDados.Livros[posicao];



            if (carrinho.Count == 3)
            {
                MessageBox.Show("Cada empréstimo pode ter no máximo 3 livros!", "ADS/JIPA", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }


            if (livro.Exemplares == 0)
            {
                MessageBox.Show("Este livro não tem exemplares disponíveis!", "ADS/JIPA", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }


            if (carrinho.Any(x => x.Posicao == posicao))
            {
                MessageBox.Show("Este livro já foi adicionado ao empréstimo!", "ADS/JIPA", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            carrinho.Add((posicao, livro.Titulo, livro.Autor));


            cmbLeitor.Enabled = false;

            AtualizarGrid();
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            if (carrinho.Count == 0)
            {
                MessageBox.Show("Adicione pelo menos um livro ao empréstimo!", "ADS/JIPA", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int codigo = BancoDados.ProximoCodigoEmprestimo;
            Leitor leitor = BancoDados.Leitores[cmbLeitor.SelectedIndex];

            foreach (var item in carrinho)
            {
                var livro = BancoDados.Livros[item.Posicao];

                BancoDados.Emprestimos.Add((codigo, leitor.Matricula, leitor.Nome,
                                            livro.Titulo, livro.Autor,
                                            dataEmprestimo, dataDevolucao));


                livro.Exemplares--;
                BancoDados.Livros[item.Posicao] = livro;
            }

            BancoDados.ProximoCodigoEmprestimo++;

            MessageBox.Show("Empréstimo " + codigo + " salvo com sucesso!", "ADS/JIPA", MessageBoxButtons.OK, MessageBoxIcon.Information);

            LimparTela();
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            LimparTela();
        }

        private void AtualizarGrid()
        {
            dgvEmprestimo.DataSource = carrinho
                .Select(x => new
                {
                    Código = BancoDados.ProximoCodigoEmprestimo,
                    Matrícula = txtMatricula.Text,
                    Título = x.Titulo,
                    Autor = x.Autor,
                    Empréstimo = dataEmprestimo.ToString("dd/MM/yyyy"),
                    Devolução = dataDevolucao.ToString("dd/MM/yyyy")
                })
                .ToList();
        }

        private void LimparTela()
        {
            carrinho.Clear();

            cmbLeitor.Enabled = true;
            cmbLeitor.SelectedIndex = -1;
            cmbLivro.SelectedIndex = -1;

            txtMatricula.Clear();
            txtTitulo.Clear();
            txtAutor.Clear();
            txtGenero.Clear();
            txtExemplares.Clear();

            AtualizarGrid();
        }

        private void dgvEmprestimo_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}