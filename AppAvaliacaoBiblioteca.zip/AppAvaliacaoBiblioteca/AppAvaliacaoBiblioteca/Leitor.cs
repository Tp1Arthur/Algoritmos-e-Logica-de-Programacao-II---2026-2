﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AppAvaliacaoBiblioteca
{
    public class Leitor
    {
        public string Nome { get; set; }
        public string Matricula { get; set; }
        public string Curso { get; set; }
        public string Telefone { get; set; }
    }
}
