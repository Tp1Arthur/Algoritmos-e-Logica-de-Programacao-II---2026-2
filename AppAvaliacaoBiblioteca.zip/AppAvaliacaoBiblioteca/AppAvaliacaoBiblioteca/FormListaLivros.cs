﻿using AppAvaliacaoBiblioteca.Contexto;

namespace AppAvaliacaoBiblioteca
{
    public partial class FormListaLivros : Form
    {
        public FormListaLivros()
        {
            InitializeComponent();
        }

        private void FormListaLivros_Load(object sender, EventArgs e)
        {
            dgvLivros.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            Filtrar();
        }

        private void btnFiltrar_Click(object sender, EventArgs e)
        {
            Filtrar();
        }

        private void Filtrar()
        {
            string filtroTitulo = txtTitulo.Text.Trim().ToLower();
            string filtroGenero = txtGenero.Text.Trim().ToLower();


            dgvLivros.DataSource = BancoDados.Livros
                .Where(l => l.Titulo.ToLower().Contains(filtroTitulo) &&
                            l.Genero.ToLower().Contains(filtroGenero))
                .Select(l => new
                {
                    l.Id,
                    l.Titulo,
                    l.Autor,
                    l.Genero,
                    l.Exemplares
                })
                .ToList();
        }

        private void dgvLivros_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}