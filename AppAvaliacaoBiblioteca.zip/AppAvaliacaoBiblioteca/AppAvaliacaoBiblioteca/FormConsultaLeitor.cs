﻿using AppAvaliacaoBiblioteca.Contexto;

namespace AppAvaliacaoBiblioteca
{
    public partial class FormConsultaLeitor : Form
    {
        public FormConsultaLeitor()
        {
            InitializeComponent();
        }

        private void FormConsultaLeitor_Load(object sender, EventArgs e)
        {
            txtNome.ReadOnly = true;
            txtMatricula.ReadOnly = true;
            txtCurso.ReadOnly = true;
            txtTelefone.ReadOnly = true;
            txtTotal.ReadOnly = true;


            cmbLeitor.DataSource = BancoDados.Leitores.ToList();
            cmbLeitor.DisplayMember = "Nome";
            cmbLeitor.SelectedIndex = -1;

            txtNome.Clear();
            txtMatricula.Clear();
            txtCurso.Clear();
            txtTelefone.Clear();
            txtTotal.Clear();
        }

        private void cmbLeitor_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbLeitor.SelectedIndex == -1)
            {
                return;
            }

            Leitor leitor = BancoDados.Leitores[cmbLeitor.SelectedIndex];

            txtNome.Text = leitor.Nome;
            txtMatricula.Text = leitor.Matricula;
            txtCurso.Text = leitor.Curso;
            txtTelefone.Text = leitor.Telefone;

            int total = BancoDados.Emprestimos
                .Where(emp => emp.Matricula == leitor.Matricula)
                .Count();

            txtTotal.Text = total.ToString();
        }

        private void lblTituloTela_Click(object sender, EventArgs e)
        {

        }
    }
}