﻿namespace AppAvaliacaoBiblioteca
{
    partial class FormMenu
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnCadastrarLivro = new Button();
            btnCadastrarLeitor = new Button();
            btnRegistrarEmprestimo = new Button();
            btnConsultarLeitor = new Button();
            btnListarEmprestimos = new Button();
            btnListarLivros = new Button();
            label1 = new Label();
            SuspendLayout();
            // 
            // btnCadastrarLivro
            // 
            btnCadastrarLivro.BackColor = Color.MediumSeaGreen;
            btnCadastrarLivro.BackgroundImageLayout = ImageLayout.None;
            btnCadastrarLivro.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnCadastrarLivro.ForeColor = SystemColors.ButtonHighlight;
            btnCadastrarLivro.Location = new Point(358, 115);
            btnCadastrarLivro.Name = "btnCadastrarLivro";
            btnCadastrarLivro.Size = new Size(179, 63);
            btnCadastrarLivro.TabIndex = 0;
            btnCadastrarLivro.Text = "Cadastrar Livro";
            btnCadastrarLivro.UseVisualStyleBackColor = false;
            btnCadastrarLivro.Click += btnCadastrarLivro_Click;
            // 
            // btnCadastrarLeitor
            // 
            btnCadastrarLeitor.BackColor = Color.MediumSeaGreen;
            btnCadastrarLeitor.BackgroundImageLayout = ImageLayout.None;
            btnCadastrarLeitor.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnCadastrarLeitor.ForeColor = SystemColors.ButtonHighlight;
            btnCadastrarLeitor.Location = new Point(560, 115);
            btnCadastrarLeitor.Name = "btnCadastrarLeitor";
            btnCadastrarLeitor.Size = new Size(179, 63);
            btnCadastrarLeitor.TabIndex = 1;
            btnCadastrarLeitor.Text = "Cadastrar Leitor";
            btnCadastrarLeitor.UseVisualStyleBackColor = false;
            btnCadastrarLeitor.Click += btnCadastrarLeitor_Click;
            // 
            // btnRegistrarEmprestimo
            // 
            btnRegistrarEmprestimo.BackColor = Color.MediumSeaGreen;
            btnRegistrarEmprestimo.BackgroundImageLayout = ImageLayout.None;
            btnRegistrarEmprestimo.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnRegistrarEmprestimo.ForeColor = SystemColors.ButtonHighlight;
            btnRegistrarEmprestimo.Location = new Point(358, 184);
            btnRegistrarEmprestimo.Name = "btnRegistrarEmprestimo";
            btnRegistrarEmprestimo.Size = new Size(179, 63);
            btnRegistrarEmprestimo.TabIndex = 2;
            btnRegistrarEmprestimo.Text = "Registrar Empréstimo";
            btnRegistrarEmprestimo.UseVisualStyleBackColor = false;
            btnRegistrarEmprestimo.Click += btnRegistrarEmprestimo_Click;
            // 
            // btnConsultarLeitor
            // 
            btnConsultarLeitor.BackColor = Color.MediumSeaGreen;
            btnConsultarLeitor.BackgroundImageLayout = ImageLayout.None;
            btnConsultarLeitor.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnConsultarLeitor.ForeColor = SystemColors.ButtonHighlight;
            btnConsultarLeitor.Location = new Point(560, 184);
            btnConsultarLeitor.Name = "btnConsultarLeitor";
            btnConsultarLeitor.Size = new Size(179, 63);
            btnConsultarLeitor.TabIndex = 3;
            btnConsultarLeitor.Text = "Consultar Leitor";
            btnConsultarLeitor.UseVisualStyleBackColor = false;
            btnConsultarLeitor.Click += btnConsultarLeitor_Click;
            // 
            // btnListarEmprestimos
            // 
            btnListarEmprestimos.BackColor = Color.MediumSeaGreen;
            btnListarEmprestimos.BackgroundImageLayout = ImageLayout.None;
            btnListarEmprestimos.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnListarEmprestimos.ForeColor = SystemColors.ButtonHighlight;
            btnListarEmprestimos.Location = new Point(560, 253);
            btnListarEmprestimos.Name = "btnListarEmprestimos";
            btnListarEmprestimos.Size = new Size(179, 63);
            btnListarEmprestimos.TabIndex = 4;
            btnListarEmprestimos.Text = "Listar Empréstimos";
            btnListarEmprestimos.UseVisualStyleBackColor = false;
            btnListarEmprestimos.Click += btnListarEmprestimos_Click;
            // 
            // btnListarLivros
            // 
            btnListarLivros.BackColor = Color.MediumSeaGreen;
            btnListarLivros.BackgroundImageLayout = ImageLayout.None;
            btnListarLivros.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnListarLivros.ForeColor = SystemColors.ButtonHighlight;
            btnListarLivros.Location = new Point(358, 253);
            btnListarLivros.Name = "btnListarLivros";
            btnListarLivros.Size = new Size(179, 63);
            btnListarLivros.TabIndex = 5;
            btnListarLivros.Text = "Listar Livros";
            btnListarLivros.UseVisualStyleBackColor = false;
            btnListarLivros.Click += btnListarLivros_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(12, 411);
            label1.Name = "label1";
            label1.Size = new Size(371, 30);
            label1.TabIndex = 6;
            label1.Text = "Aluno: Arthur Ricardo de Jesus Silva";
            // 
            // FormMenu
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(800, 450);
            Controls.Add(label1);
            Controls.Add(btnListarLivros);
            Controls.Add(btnListarEmprestimos);
            Controls.Add(btnConsultarLeitor);
            Controls.Add(btnRegistrarEmprestimo);
            Controls.Add(btnCadastrarLeitor);
            Controls.Add(btnCadastrarLivro);
            Name = "FormMenu";
            Text = "FormMenu";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnCadastrarLivro;
        private Button btnCadastrarLeitor;
        private Button btnRegistrarEmprestimo;
        private Button btnConsultarLeitor;
        private Button btnListarEmprestimos;
        private Button btnListarLivros;
        private Label label1;
    }
}
