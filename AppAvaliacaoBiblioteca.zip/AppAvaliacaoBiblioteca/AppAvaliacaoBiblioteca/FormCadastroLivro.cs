﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using AppAvaliacaoBiblioteca.Contexto;

namespace AppAvaliacaoBiblioteca
{
    public partial class FormCadastroLivro : Form
    {
        public FormCadastroLivro()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void txtTitulo_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtAutor_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtGenero_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtExemplares_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnCadastrar_Click(object sender, EventArgs e)
        {

            string titulo = txtTitulo.Text.Trim();
            string autor = txtAutor.Text.Trim();
            string genero = txtGenero.Text.Trim();
            string textoQuantidade = txtExemplares.Text.Trim();

            if (titulo == "" || autor == "" || genero == "" || textoQuantidade == "")
            {
                MessageBox.Show("Preencha todos os campos!", "ADS/JIPA", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int quantidade;
            try
            {
                quantidade = Convert.ToInt32(textoQuantidade);
            }
            catch
            {
                MessageBox.Show("A quantidade de exemplares deve ser um número inteiro!", "ADS/JIPA", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtExemplares.Select();
                return;
            }

            if (quantidade <= 0)
            {
                MessageBox.Show("A quantidade de exemplares deve ser maior que zero!", "ADS/JIPA", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtExemplares.Select();
                return;
            }

            var livro = (Id: BancoDados.ProximoIdLivro,
                         Titulo: titulo,
                         Autor: autor,
                         Genero: genero,
                         Exemplares: quantidade);

            BancoDados.Livros.Add(livro);
            BancoDados.ProximoIdLivro++;

            MessageBox.Show("Livro cadastrado com sucesso!", "ADS/JIPA", MessageBoxButtons.OK, MessageBoxIcon.Information);


            txtTitulo.Clear();
            txtAutor.Clear();
            txtGenero.Clear();
            txtExemplares.Clear();
            txtTitulo.Select();
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}