﻿namespace AppAvaliacaoBiblioteca
{
    partial class FormConsultaLeitor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblTituloTela = new Label();
            lblLeitor = new Label();
            cmbLeitor = new ComboBox();
            lblNome = new Label();
            txtNome = new TextBox();
            lblMatricula = new Label();
            txtMatricula = new TextBox();
            lblCurso = new Label();
            txtCurso = new TextBox();
            lblTelefone = new Label();
            txtTelefone = new TextBox();
            lblTotal = new Label();
            txtTotal = new TextBox();
            SuspendLayout();
            // 
            // lblTituloTela
            // 
            lblTituloTela.Font = new Font("Arial", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblTituloTela.Location = new Point(8, 20);
            lblTituloTela.Name = "lblTituloTela";
            lblTituloTela.Size = new Size(780, 23);
            lblTituloTela.TabIndex = 0;
            lblTituloTela.Text = "Consultar Leitores";
            lblTituloTela.TextAlign = ContentAlignment.MiddleCenter;
            lblTituloTela.Click += lblTituloTela_Click;
            // 
            // lblLeitor
            // 
            lblLeitor.AutoSize = true;
            lblLeitor.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            lblLeitor.Location = new Point(12, 55);
            lblLeitor.Name = "lblLeitor";
            lblLeitor.Size = new Size(104, 15);
            lblLeitor.TabIndex = 1;
            lblLeitor.Text = "Selecionar Leitor:";
            // 
            // cmbLeitor
            // 
            cmbLeitor.BackColor = Color.FromArgb(224, 224, 224);
            cmbLeitor.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbLeitor.FormattingEnabled = true;
            cmbLeitor.Location = new Point(12, 75);
            cmbLeitor.Name = "cmbLeitor";
            cmbLeitor.Size = new Size(776, 23);
            cmbLeitor.TabIndex = 2;
            cmbLeitor.SelectedIndexChanged += cmbLeitor_SelectedIndexChanged;
            // 
            // lblNome
            // 
            lblNome.AutoSize = true;
            lblNome.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            lblNome.Location = new Point(12, 120);
            lblNome.Name = "lblNome";
            lblNome.Size = new Size(44, 15);
            lblNome.TabIndex = 3;
            lblNome.Text = "Nome:";
            // 
            // txtNome
            // 
            txtNome.BackColor = Color.FromArgb(224, 224, 224);
            txtNome.Location = new Point(12, 140);
            txtNome.Name = "txtNome";
            txtNome.Size = new Size(776, 23);
            txtNome.TabIndex = 4;
            // 
            // lblMatricula
            // 
            lblMatricula.AutoSize = true;
            lblMatricula.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            lblMatricula.Location = new Point(12, 180);
            lblMatricula.Name = "lblMatricula";
            lblMatricula.Size = new Size(62, 15);
            lblMatricula.TabIndex = 5;
            lblMatricula.Text = "Matrícula:";
            // 
            // txtMatricula
            // 
            txtMatricula.BackColor = Color.FromArgb(224, 224, 224);
            txtMatricula.Location = new Point(12, 200);
            txtMatricula.Name = "txtMatricula";
            txtMatricula.Size = new Size(776, 23);
            txtMatricula.TabIndex = 6;
            // 
            // lblCurso
            // 
            lblCurso.AutoSize = true;
            lblCurso.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            lblCurso.Location = new Point(12, 240);
            lblCurso.Name = "lblCurso";
            lblCurso.Size = new Size(41, 15);
            lblCurso.TabIndex = 7;
            lblCurso.Text = "Curso:";
            // 
            // txtCurso
            // 
            txtCurso.BackColor = Color.FromArgb(224, 224, 224);
            txtCurso.Location = new Point(12, 260);
            txtCurso.Name = "txtCurso";
            txtCurso.Size = new Size(380, 23);
            txtCurso.TabIndex = 8;
            // 
            // lblTelefone
            // 
            lblTelefone.AutoSize = true;
            lblTelefone.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            lblTelefone.Location = new Point(408, 240);
            lblTelefone.Name = "lblTelefone";
            lblTelefone.Size = new Size(59, 15);
            lblTelefone.TabIndex = 9;
            lblTelefone.Text = "Telefone:";
            // 
            // txtTelefone
            // 
            txtTelefone.BackColor = Color.FromArgb(224, 224, 224);
            txtTelefone.Location = new Point(408, 260);
            txtTelefone.Name = "txtTelefone";
            txtTelefone.Size = new Size(380, 23);
            txtTelefone.TabIndex = 10;
            // 
            // lblTotal
            // 
            lblTotal.AutoSize = true;
            lblTotal.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            lblTotal.Location = new Point(12, 300);
            lblTotal.Name = "lblTotal";
            lblTotal.Size = new Size(174, 15);
            lblTotal.TabIndex = 11;
            lblTotal.Text = "Total de livros já emprestados:";
            // 
            // txtTotal
            // 
            txtTotal.BackColor = Color.FromArgb(224, 224, 224);
            txtTotal.Location = new Point(12, 320);
            txtTotal.Name = "txtTotal";
            txtTotal.Size = new Size(776, 23);
            txtTotal.TabIndex = 12;
            // 
            // FormConsultaLeitor
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(txtTotal);
            Controls.Add(lblTotal);
            Controls.Add(txtTelefone);
            Controls.Add(lblTelefone);
            Controls.Add(txtCurso);
            Controls.Add(lblCurso);
            Controls.Add(txtMatricula);
            Controls.Add(lblMatricula);
            Controls.Add(txtNome);
            Controls.Add(lblNome);
            Controls.Add(cmbLeitor);
            Controls.Add(lblLeitor);
            Controls.Add(lblTituloTela);
            Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            Name = "FormConsultaLeitor";
            Text = "Consultar Leitores";
            Load += FormConsultaLeitor_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblTituloTela;
        private Label lblLeitor;
        private ComboBox cmbLeitor;
        private Label lblNome;
        private TextBox txtNome;
        private Label lblMatricula;
        private TextBox txtMatricula;
        private Label lblCurso;
        private TextBox txtCurso;
        private Label lblTelefone;
        private TextBox txtTelefone;
        private Label lblTotal;
        private TextBox txtTotal;
    }
}