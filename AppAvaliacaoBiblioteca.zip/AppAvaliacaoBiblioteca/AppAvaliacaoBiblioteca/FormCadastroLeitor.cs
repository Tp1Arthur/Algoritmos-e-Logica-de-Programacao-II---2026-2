﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using AppAvaliacaoBiblioteca.Contexto;

namespace AppAvaliacaoBiblioteca
{
    public partial class FormCadastroLeitor : Form
    {
        public FormCadastroLeitor()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void btnCadastrar_Click(object sender, EventArgs e)
        {
            string nome = txtNome.Text.Trim();
            string matricula = txtMatricula.Text.Trim();
            string curso = txtCurso.Text.Trim();
            string telefone = txtTelefone.Text.Trim();

            if (nome == "" || matricula == "" || curso == "" || telefone == "")
            {
                MessageBox.Show("Preencha todos os campos!", "ADS/JIPA", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }


            foreach (Leitor l in BancoDados.Leitores)
            {
                if (l.Matricula == matricula)
                {
                    MessageBox.Show("Já existe um leitor com essa matrícula!", "ADS/JIPA", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtMatricula.Select();
                    return;
                }
            }

            Leitor leitor = new Leitor();
            leitor.Nome = nome;
            leitor.Matricula = matricula;
            leitor.Curso = curso;
            leitor.Telefone = telefone;

            BancoDados.Leitores.Add(leitor);

            MessageBox.Show("Leitor cadastrado com sucesso!", "ADS/JIPA", MessageBoxButtons.OK, MessageBoxIcon.Information);

            txtNome.Clear();
            txtMatricula.Clear();
            txtCurso.Clear();
            txtTelefone.Clear();
            txtNome.Select();
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}