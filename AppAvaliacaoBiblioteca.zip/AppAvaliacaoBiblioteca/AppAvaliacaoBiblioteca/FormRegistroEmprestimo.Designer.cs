﻿namespace AppAvaliacaoBiblioteca
{
    partial class FormRegistroEmprestimo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblTituloTela = new Label();
            lblLeitor = new Label();
            lblLivro = new Label();
            lblTitulo = new Label();
            lblAutor = new Label();
            lblGenero = new Label();
            lblExemplares = new Label();
            lblMatricula = new Label();
            lblDataEmprestimo = new Label();
            lblDevolucao = new Label();
            cmbLeitor = new ComboBox();
            cmbLivro = new ComboBox();
            txtTitulo = new TextBox();
            txtAutor = new TextBox();
            txtGenero = new TextBox();
            txtExemplares = new TextBox();
            txtMatricula = new TextBox();
            txtDataEmprestimo = new TextBox();
            txtDevolucao = new TextBox();
            btnAdicionar = new Button();
            dgvEmprestimo = new DataGridView();
            btnSalvar = new Button();
            btnCancelar = new Button();
            ((System.ComponentModel.ISupportInitialize)dgvEmprestimo).BeginInit();
            SuspendLayout();
            // 
            // lblTituloTela
            // 
            lblTituloTela.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblTituloTela.Location = new Point(8, 20);
            lblTituloTela.Name = "lblTituloTela";
            lblTituloTela.Size = new Size(780, 23);
            lblTituloTela.TabIndex = 0;
            lblTituloTela.Text = "Registrar Empréstimo";
            lblTituloTela.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lblLeitor
            // 
            lblLeitor.Font = new Font("Arial Narrow", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblLeitor.Location = new Point(12, 55);
            lblLeitor.Name = "lblLeitor";
            lblLeitor.Size = new Size(366, 21);
            lblLeitor.TabIndex = 1;
            lblLeitor.Text = "Selecionar Leitor:";
            // 
            // lblLivro
            // 
            lblLivro.Font = new Font("Arial Narrow", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblLivro.Location = new Point(422, 55);
            lblLivro.Name = "lblLivro";
            lblLivro.Size = new Size(366, 21);
            lblLivro.TabIndex = 2;
            lblLivro.Text = "Selecionar Livro:";
            // 
            // lblTitulo
            // 
            lblTitulo.AutoSize = true;
            lblTitulo.Location = new Point(12, 114);
            lblTitulo.Name = "lblTitulo";
            lblTitulo.Size = new Size(41, 15);
            lblTitulo.TabIndex = 5;
            lblTitulo.Text = "Título:";
            // 
            // lblAutor
            // 
            lblAutor.AutoSize = true;
            lblAutor.Location = new Point(210, 114);
            lblAutor.Name = "lblAutor";
            lblAutor.Size = new Size(40, 15);
            lblAutor.TabIndex = 6;
            lblAutor.Text = "Autor:";
            // 
            // lblGenero
            // 
            lblGenero.AutoSize = true;
            lblGenero.Location = new Point(422, 114);
            lblGenero.Name = "lblGenero";
            lblGenero.Size = new Size(48, 15);
            lblGenero.TabIndex = 7;
            lblGenero.Text = "Gênero:";
            // 
            // lblExemplares
            // 
            lblExemplares.AutoSize = true;
            lblExemplares.Location = new Point(620, 114);
            lblExemplares.Name = "lblExemplares";
            lblExemplares.Size = new Size(131, 15);
            lblExemplares.TabIndex = 8;
            lblExemplares.Text = "Exemplares disponíveis:";
            // 
            // lblMatricula
            // 
            lblMatricula.AutoSize = true;
            lblMatricula.Location = new Point(12, 174);
            lblMatricula.Name = "lblMatricula";
            lblMatricula.Size = new Size(107, 15);
            lblMatricula.TabIndex = 13;
            lblMatricula.Text = "Matrícula do leitor:";
            // 
            // lblDataEmprestimo
            // 
            lblDataEmprestimo.AutoSize = true;
            lblDataEmprestimo.Location = new Point(289, 174);
            lblDataEmprestimo.Name = "lblDataEmprestimo";
            lblDataEmprestimo.Size = new Size(118, 15);
            lblDataEmprestimo.TabIndex = 14;
            lblDataEmprestimo.Text = "Data do empréstimo:";
            // 
            // lblDevolucao
            // 
            lblDevolucao.AutoSize = true;
            lblDevolucao.Location = new Point(557, 174);
            lblDevolucao.Name = "lblDevolucao";
            lblDevolucao.Size = new Size(110, 15);
            lblDevolucao.TabIndex = 15;
            lblDevolucao.Text = "Devolução prevista:";
            // 
            // cmbLeitor
            // 
            cmbLeitor.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbLeitor.FormattingEnabled = true;
            cmbLeitor.Location = new Point(12, 79);
            cmbLeitor.Name = "cmbLeitor";
            cmbLeitor.Size = new Size(366, 23);
            cmbLeitor.TabIndex = 3;
            cmbLeitor.SelectedIndexChanged += cmbLeitor_SelectedIndexChanged;
            // 
            // cmbLivro
            // 
            cmbLivro.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbLivro.FormattingEnabled = true;
            cmbLivro.Location = new Point(422, 79);
            cmbLivro.Name = "cmbLivro";
            cmbLivro.Size = new Size(366, 23);
            cmbLivro.TabIndex = 4;
            cmbLivro.SelectedIndexChanged += cmbLivro_SelectedIndexChanged;
            // 
            // txtTitulo
            // 
            txtTitulo.Location = new Point(12, 133);
            txtTitulo.Name = "txtTitulo";
            txtTitulo.Size = new Size(168, 23);
            txtTitulo.TabIndex = 9;
            // 
            // txtAutor
            // 
            txtAutor.Location = new Point(210, 133);
            txtAutor.Name = "txtAutor";
            txtAutor.Size = new Size(168, 23);
            txtAutor.TabIndex = 10;
            // 
            // txtGenero
            // 
            txtGenero.Location = new Point(422, 133);
            txtGenero.Name = "txtGenero";
            txtGenero.Size = new Size(168, 23);
            txtGenero.TabIndex = 11;
            // 
            // txtExemplares
            // 
            txtExemplares.Location = new Point(620, 133);
            txtExemplares.Name = "txtExemplares";
            txtExemplares.Size = new Size(168, 23);
            txtExemplares.TabIndex = 12;
            // 
            // txtMatricula
            // 
            txtMatricula.Location = new Point(12, 193);
            txtMatricula.Name = "txtMatricula";
            txtMatricula.Size = new Size(231, 23);
            txtMatricula.TabIndex = 16;
            // 
            // txtDataEmprestimo
            // 
            txtDataEmprestimo.Location = new Point(289, 193);
            txtDataEmprestimo.Name = "txtDataEmprestimo";
            txtDataEmprestimo.Size = new Size(231, 23);
            txtDataEmprestimo.TabIndex = 17;
            // 
            // txtDevolucao
            // 
            txtDevolucao.Location = new Point(557, 193);
            txtDevolucao.Name = "txtDevolucao";
            txtDevolucao.Size = new Size(231, 23);
            txtDevolucao.TabIndex = 18;
            // 
            // btnAdicionar
            // 
            btnAdicionar.Font = new Font("Arial Narrow", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnAdicionar.Location = new Point(333, 232);
            btnAdicionar.Name = "btnAdicionar";
            btnAdicionar.Size = new Size(135, 31);
            btnAdicionar.TabIndex = 19;
            btnAdicionar.Text = "ADICIONAR (+)";
            btnAdicionar.UseVisualStyleBackColor = true;
            btnAdicionar.Click += btnAdicionar_Click;
            // 
            // dgvEmprestimo
            // 
            dgvEmprestimo.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvEmprestimo.Location = new Point(12, 281);
            dgvEmprestimo.Name = "dgvEmprestimo";
            dgvEmprestimo.Size = new Size(776, 113);
            dgvEmprestimo.TabIndex = 20;
            dgvEmprestimo.CellContentClick += dgvEmprestimo_CellContentClick;
            // 
            // btnSalvar
            // 
            btnSalvar.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnSalvar.Location = new Point(218, 415);
            btnSalvar.Name = "btnSalvar";
            btnSalvar.Size = new Size(160, 23);
            btnSalvar.TabIndex = 21;
            btnSalvar.Text = "SALVAR EMPRÉSTIMO";
            btnSalvar.UseVisualStyleBackColor = true;
            btnSalvar.Click += btnSalvar_Click;
            // 
            // btnCancelar
            // 
            btnCancelar.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnCancelar.Location = new Point(411, 415);
            btnCancelar.Name = "btnCancelar";
            btnCancelar.Size = new Size(179, 23);
            btnCancelar.TabIndex = 22;
            btnCancelar.Text = "CANCELAR EMPRÉSTIMO";
            btnCancelar.UseVisualStyleBackColor = true;
            btnCancelar.Click += btnCancelar_Click;
            // 
            // FormRegistroEmprestimo
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnCancelar);
            Controls.Add(btnSalvar);
            Controls.Add(dgvEmprestimo);
            Controls.Add(btnAdicionar);
            Controls.Add(txtDevolucao);
            Controls.Add(txtDataEmprestimo);
            Controls.Add(txtMatricula);
            Controls.Add(lblDevolucao);
            Controls.Add(lblDataEmprestimo);
            Controls.Add(lblMatricula);
            Controls.Add(txtExemplares);
            Controls.Add(txtGenero);
            Controls.Add(txtAutor);
            Controls.Add(txtTitulo);
            Controls.Add(lblExemplares);
            Controls.Add(lblGenero);
            Controls.Add(lblAutor);
            Controls.Add(lblTitulo);
            Controls.Add(cmbLivro);
            Controls.Add(cmbLeitor);
            Controls.Add(lblLivro);
            Controls.Add(lblLeitor);
            Controls.Add(lblTituloTela);
            Name = "FormRegistroEmprestimo";
            Text = "Registrar Empréstimo";
            Load += FormRegistroEmprestimo_Load;
            ((System.ComponentModel.ISupportInitialize)dgvEmprestimo).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblTituloTela;
        private Label lblLeitor;
        private Label lblLivro;
        private Label lblTitulo;
        private Label lblAutor;
        private Label lblGenero;
        private Label lblExemplares;
        private Label lblMatricula;
        private Label lblDataEmprestimo;
        private Label lblDevolucao;
        private ComboBox cmbLeitor;
        private ComboBox cmbLivro;
        private TextBox txtTitulo;
        private TextBox txtAutor;
        private TextBox txtGenero;
        private TextBox txtExemplares;
        private TextBox txtMatricula;
        private TextBox txtDataEmprestimo;
        private TextBox txtDevolucao;
        private Button btnAdicionar;
        private DataGridView dgvEmprestimo;
        private Button btnSalvar;
        private Button btnCancelar;
    }
}