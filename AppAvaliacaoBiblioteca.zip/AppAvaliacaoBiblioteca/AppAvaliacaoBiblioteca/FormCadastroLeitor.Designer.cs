﻿namespace AppAvaliacaoBiblioteca
{
    partial class FormCadastroLeitor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            txtNome = new TextBox();
            txtMatricula = new TextBox();
            txtCurso = new TextBox();
            txtTelefone = new TextBox();
            label3 = new Label();
            label2 = new Label();
            label4 = new Label();
            label5 = new Label();
            btnCadastrar = new Button();
            btnCancelar = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.Font = new Font("Arial", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(12, 21);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(776, 23);
            label1.TabIndex = 0;
            label1.Text = "Cadastrar Leitor";
            label1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // txtNome
            // 
            txtNome.BackColor = Color.FromArgb(224, 224, 224);
            txtNome.Font = new Font("Arial Narrow", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtNome.Location = new Point(13, 75);
            txtNome.Margin = new Padding(4, 3, 4, 3);
            txtNome.Name = "txtNome";
            txtNome.Size = new Size(774, 26);
            txtNome.TabIndex = 1;
            // 
            // txtMatricula
            // 
            txtMatricula.BackColor = Color.FromArgb(224, 224, 224);
            txtMatricula.Font = new Font("Arial Narrow", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtMatricula.Location = new Point(13, 154);
            txtMatricula.Margin = new Padding(4, 3, 4, 3);
            txtMatricula.Name = "txtMatricula";
            txtMatricula.Size = new Size(774, 26);
            txtMatricula.TabIndex = 2;
            // 
            // txtCurso
            // 
            txtCurso.BackColor = Color.FromArgb(224, 224, 224);
            txtCurso.Font = new Font("Arial Narrow", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtCurso.Location = new Point(13, 238);
            txtCurso.Margin = new Padding(4, 3, 4, 3);
            txtCurso.Name = "txtCurso";
            txtCurso.Size = new Size(774, 26);
            txtCurso.TabIndex = 3;
            // 
            // txtTelefone
            // 
            txtTelefone.BackColor = Color.FromArgb(224, 224, 224);
            txtTelefone.Font = new Font("Arial Narrow", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtTelefone.Location = new Point(13, 315);
            txtTelefone.Margin = new Padding(4, 3, 4, 3);
            txtTelefone.Name = "txtTelefone";
            txtTelefone.Size = new Size(774, 26);
            txtTelefone.TabIndex = 4;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Arial", 12F, FontStyle.Bold);
            label3.Location = new Point(13, 53);
            label3.Margin = new Padding(4, 0, 4, 0);
            label3.Name = "label3";
            label3.Size = new Size(60, 19);
            label3.TabIndex = 6;
            label3.Text = "Nome:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Arial", 12F, FontStyle.Bold);
            label2.Location = new Point(13, 132);
            label2.Margin = new Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new Size(84, 19);
            label2.TabIndex = 7;
            label2.Text = "Matrícula:";
            label2.Click += label2_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Arial", 12F, FontStyle.Bold);
            label4.Location = new Point(13, 216);
            label4.Margin = new Padding(4, 0, 4, 0);
            label4.Name = "label4";
            label4.Size = new Size(62, 19);
            label4.TabIndex = 8;
            label4.Text = "Curso:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Arial", 12F, FontStyle.Bold);
            label5.Location = new Point(13, 293);
            label5.Margin = new Padding(4, 0, 4, 0);
            label5.Name = "label5";
            label5.Size = new Size(80, 19);
            label5.TabIndex = 9;
            label5.Text = "Telefone:";
            // 
            // btnCadastrar
            // 
            btnCadastrar.BackColor = Color.Green;
            btnCadastrar.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnCadastrar.ForeColor = SystemColors.ControlLightLight;
            btnCadastrar.Location = new Point(194, 380);
            btnCadastrar.Name = "btnCadastrar";
            btnCadastrar.Size = new Size(160, 36);
            btnCadastrar.TabIndex = 10;
            btnCadastrar.Text = "CADASTRAR";
            btnCadastrar.UseVisualStyleBackColor = false;
            btnCadastrar.Click += btnCadastrar_Click;
            // 
            // btnCancelar
            // 
            btnCancelar.BackColor = Color.Green;
            btnCancelar.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnCancelar.ForeColor = SystemColors.ControlLightLight;
            btnCancelar.Location = new Point(417, 380);
            btnCancelar.Name = "btnCancelar";
            btnCancelar.Size = new Size(160, 36);
            btnCancelar.TabIndex = 11;
            btnCancelar.Text = "CANCELAR";
            btnCancelar.UseVisualStyleBackColor = false;
            btnCancelar.Click += btnCancelar_Click;
            // 
            // FormCadastroLeitor
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnCancelar);
            Controls.Add(btnCadastrar);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label2);
            Controls.Add(label3);
            Controls.Add(txtTelefone);
            Controls.Add(txtCurso);
            Controls.Add(txtMatricula);
            Controls.Add(txtNome);
            Controls.Add(label1);
            Margin = new Padding(4, 3, 4, 3);
            Name = "FormCadastroLeitor";
            Text = "FormCadastroLeitor";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox txtNome;
        private TextBox txtMatricula;
        private TextBox txtCurso;
        private TextBox txtTelefone;
        private Label label3;
        private Label label2;
        private Label label4;
        private Label label5;
        private Button btnCadastrar;
        private Button btnCancelar;
    }
}