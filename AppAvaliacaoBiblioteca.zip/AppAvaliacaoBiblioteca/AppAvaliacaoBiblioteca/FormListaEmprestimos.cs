﻿using AppAvaliacaoBiblioteca.Contexto;

namespace AppAvaliacaoBiblioteca
{
    public partial class FormListaEmprestimos : Form
    {
        public FormListaEmprestimos()
        {
            InitializeComponent();
        }

        private void FormListaEmprestimos_Load(object sender, EventArgs e)
        {
            dgvEmprestimos.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;


            Filtrar();
        }

        private void btnFiltrar_Click(object sender, EventArgs e)
        {
            Filtrar();
        }

        private void Filtrar()
        {
            string filtroMatricula = txtMatricula.Text.Trim();
            string filtroCodigo = txtCodigo.Text.Trim();


            dgvEmprestimos.DataSource = BancoDados.Emprestimos
                .Where(x => x.Matricula.Contains(filtroMatricula) &&
                            (filtroCodigo == "" || x.Codigo.ToString() == filtroCodigo))
                .Select(x => new
                {
                    x.Codigo,
                    x.Matricula,
                    x.Leitor,
                    x.Titulo,
                    Empréstimo = x.DataEmprestimo.ToString("dd/MM/yyyy"),
                    Devolução = x.DataDevolucao.ToString("dd/MM/yyyy")
                })
                .ToList();
        }
    }
}