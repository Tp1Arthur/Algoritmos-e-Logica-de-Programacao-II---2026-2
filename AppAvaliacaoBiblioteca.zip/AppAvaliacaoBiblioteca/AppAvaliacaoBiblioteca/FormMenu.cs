using AppAvaliacaoBiblioteca.Contexto;
using System.Numerics;

namespace AppAvaliacaoBiblioteca
{
    public partial class FormMenu : Form
    {
        public FormMenu()
        {
            InitializeComponent();
        }

        private void btnCadastrarLivro_Click(object sender, EventArgs e)
        {
            new FormCadastroLivro().ShowDialog();
        }

        private void btnCadastrarLeitor_Click(object sender, EventArgs e)
        {
            new FormCadastroLeitor().ShowDialog();
        }

        private void btnRegistrarEmprestimo_Click(object sender, EventArgs e)
        {
            new FormRegistroEmprestimo().ShowDialog();
        }

        private void btnConsultarLeitor_Click(object sender, EventArgs e)
        {
            new FormConsultaLeitor().ShowDialog();
        }

        private void btnListarLivros_Click(object sender, EventArgs e)
        {
            new FormListaLivros().ShowDialog();
        }

        private void btnListarEmprestimos_Click(object sender, EventArgs e)
        {
            new FormListaEmprestimos().ShowDialog();
        }
    }
}