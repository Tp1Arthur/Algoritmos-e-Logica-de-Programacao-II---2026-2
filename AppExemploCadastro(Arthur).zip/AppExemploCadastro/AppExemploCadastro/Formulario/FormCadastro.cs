﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AppExemploCadastro.Models;
using AppExemploCadastro.Contexto;

namespace AppExemploCadastro.Formulario
{
    public partial class FormCadastro : Form
    {
        static int idPessoa = 1;
        public FormCadastro()
        {
            InitializeComponent();
        }

        private void txtNome_TextChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void btSalvar_Click(object sender, EventArgs e)
        {
            Pessoas pessoa = new Pessoas();
            pessoa.Id = idPessoa;
            pessoa.Nome = txtNome.Text;
            pessoa.cpf = txtCpf.Text;
            pessoa.rg = txtRegistroGeral.Text;
            pessoa.email = txtEmail.Text;

            Classe.Registros.Add(pessoa);   // adiciona na lista
            idPessoa++;                     // próximo id

            MessageBox.Show("PESSOA REGISTRADA COM SUCESSO!", "ADS/JIPA", MessageBoxButtons.OK, MessageBoxIcon.Information);

            txtNome.Clear(); txtCpf.Clear(); txtRegistroGeral.Clear(); txtEmail.Clear(); txtNome.Select();
        }

        private void btCancelar_Click(object sender, EventArgs e)
        {
            txtNome.Clear(); txtCpf.Clear(); txtRegistroGeral.Clear(); txtEmail.Clear(); txtNome.Select();
        }

        private void FormCadastro_Load(object sender, EventArgs e)
        {

        }
    }
}
