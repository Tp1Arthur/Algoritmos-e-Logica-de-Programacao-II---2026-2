﻿using AppExemploCadastro.Contexto;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppExemploCadastro.Formulario
{
    public partial class FormConsultaComb : Form
    {
        int contExec = 0;
        public FormConsultaComb()
        {
            InitializeComponent();
            comboBox1.DataSource = Classe.Registros.ToList();
            comboBox1.DisplayMember = "Nome";
            comboBox1.SelectedIndex = -1;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            contExec++;
            int linhaSelecionada = comboBox1.SelectedIndex;
            if (linhaSelecionada > -1 && contExec > 1)
            {
                var pessoa = Classe.Registros[linhaSelecionada];
                txtNome.Text = pessoa.Nome;
                txtCpf.Text = pessoa.cpf;
                txtRegistroGeral.Text = pessoa.rg;
                txtEmail.Text = pessoa.email;
                
            }
        }

        private void label6_Click(object sender, EventArgs e)
        {
            

        }
    }
}
