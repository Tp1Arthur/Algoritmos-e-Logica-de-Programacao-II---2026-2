﻿using AppExemploCadastro.Contexto;
using AppExemploCadastro.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AppExemploCadastro.Models;

namespace AppExemploCadastro.Formulario
{
    public partial class FormLista : Form
    {
        List<Pessoas> pessoas = new List<Pessoas>();
        public FormLista()
        {
            InitializeComponent();
            pessoas = Classe.Registros.ToList();
            dtTabela.DataSource = Classe.Registros.ToList();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void dtTabela_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void FormLista_Load(object sender, EventArgs e)
        {
            dtTabela.DataSource = Classe.Registros.ToList();
        }
    }
}
