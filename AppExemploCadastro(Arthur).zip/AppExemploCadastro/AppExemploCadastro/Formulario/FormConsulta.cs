﻿using AppExemploCadastro.Contexto;
using AppExemploCadastro.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace AppExemploCadastro.Formulario
{
    public partial class FormConsulta : Form
    {
        public FormConsulta()
        {
            InitializeComponent();
        }

        private void FormConsulta_Load(object sender, EventArgs e)
        {
            dtTabela.DataSource = Classe.Registros.ToList();
        }

        private void txtNome_TextChanged(object sender, EventArgs e)
        {
            Pesquisar();
        }

        private void btPesquisa_Click(object sender, EventArgs e)
        {
            Pesquisar();
        }

        private void dtTabela_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        }

        private void Pesquisar()
        {
            string nome = txtNome.Text.Trim();
            List<Pessoas> resultado;

            if (nome == "")
            {
                resultado = Classe.Registros.ToList();
            }
            else
            {
                resultado = Classe.Registros
                    .Where(p => p.Nome != null && p.Nome.IndexOf(nome, StringComparison.OrdinalIgnoreCase) >= 0).ToList();
            }

            dtTabela.DataSource = resultado;
        }
    }
}