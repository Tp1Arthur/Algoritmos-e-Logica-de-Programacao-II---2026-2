﻿using AppExemploCadastro.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppExemploCadastro.Contexto
{
    internal class Classe
    {
        public static List<Pessoas> Registros = new List<Pessoas>();
    }
}
